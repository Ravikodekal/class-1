#!/bin/bash

backup_folder="/home/ec2-user/backup_folder"
source_folder="/home/ec2-user/scripts"

# Move to the backup folder
cd "$backup_folder"

# Count the number of existing backups
num=$(ls -l | grep -c '^-' )  # Count only regular files, excluding directories

# Create the backup filename
backup_filename="backup_$num.tar.gz"

# Create the tar archive
tar -czf "$backup_filename" -C "$source_folder" .

echo "Backup created: $backup_filename"

