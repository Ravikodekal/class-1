#!/bin/bash

echo "Hello"
echo "How are you"
